﻿namespace BookShelf
{
    partial class Tela_BuscarLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_BuscarLivro));
            panelSuperior = new Panel();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            picLogo = new PictureBox();
            lblCategoria = new Label();
            lblEditora = new Label();
            lblAutor = new Label();
            lblTitulo = new Label();
            lblCapa = new Label();
            picCapa = new PictureBox();
            label6 = new Label();
            lblCategoriaa = new Label();
            lblEditoraa = new Label();
            lblAutorr = new Label();
            lblTituloo = new Label();
            txtBuscarLivro = new TextBox();
            label1 = new Label();
            btnBuscar = new Button();
            panelSuperior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picCapa).BeginInit();
            SuspendLayout();
            // 
            // panelSuperior
            // 
            panelSuperior.BackColor = Color.Indigo;
            panelSuperior.Controls.Add(pictureBox2);
            panelSuperior.Controls.Add(pictureBox1);
            panelSuperior.Dock = DockStyle.Top;
            panelSuperior.Location = new Point(0, 0);
            panelSuperior.Name = "panelSuperior";
            panelSuperior.Size = new Size(650, 32);
            panelSuperior.TabIndex = 0;
            panelSuperior.MouseDown += panelSuperior_MouseDown;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(593, 5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(24, 24);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(623, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(224, 254, 255);
            panel2.Controls.Add(picLogo);
            panel2.Controls.Add(lblCategoria);
            panel2.Controls.Add(lblEditora);
            panel2.Controls.Add(lblAutor);
            panel2.Controls.Add(lblTitulo);
            panel2.Controls.Add(lblCapa);
            panel2.Controls.Add(picCapa);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(lblCategoriaa);
            panel2.Controls.Add(lblEditoraa);
            panel2.Controls.Add(lblAutorr);
            panel2.Controls.Add(lblTituloo);
            panel2.Controls.Add(txtBuscarLivro);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(btnBuscar);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 32);
            panel2.Name = "panel2";
            panel2.Size = new Size(650, 418);
            panel2.TabIndex = 1;
            // 
            // picLogo
            // 
            picLogo.Image = Properties.Resources._5f9d8322_69d6_45f7_ad15_8ae4619609a7;
            picLogo.Location = new Point(478, 6);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(169, 135);
            picLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            picLogo.TabIndex = 14;
            picLogo.TabStop = false;
            // 
            // lblCategoria
            // 
            lblCategoria.AutoSize = true;
            lblCategoria.Location = new Point(159, 313);
            lblCategoria.Name = "lblCategoria";
            lblCategoria.Size = new Size(72, 15);
            lblCategoria.TabIndex = 13;
            lblCategoria.Text = "<categoria>";
            // 
            // lblEditora
            // 
            lblEditora.AutoSize = true;
            lblEditora.Location = new Point(159, 280);
            lblEditora.Name = "lblEditora";
            lblEditora.Size = new Size(60, 15);
            lblEditora.TabIndex = 12;
            lblEditora.Text = "<editora>";
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.Location = new Point(159, 241);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(51, 15);
            lblAutor.TabIndex = 11;
            lblAutor.Text = "<autor>";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(159, 203);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(51, 15);
            lblTitulo.TabIndex = 10;
            lblTitulo.Text = "<titulo>";
            // 
            // lblCapa
            // 
            lblCapa.AutoSize = true;
            lblCapa.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCapa.Location = new Point(509, 162);
            lblCapa.Name = "lblCapa";
            lblCapa.Size = new Size(48, 18);
            lblCapa.TabIndex = 9;
            lblCapa.Text = "Capa:";
            // 
            // picCapa
            // 
            picCapa.Location = new Point(467, 194);
            picCapa.Name = "picCapa";
            picCapa.Size = new Size(127, 180);
            picCapa.TabIndex = 8;
            picCapa.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(52, 158);
            label6.Name = "label6";
            label6.Size = new Size(203, 23);
            label6.TabIndex = 7;
            label6.Text = "Informações do Livro:";
            // 
            // lblCategoriaa
            // 
            lblCategoriaa.AutoSize = true;
            lblCategoriaa.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCategoriaa.Location = new Point(52, 313);
            lblCategoriaa.Name = "lblCategoriaa";
            lblCategoriaa.Size = new Size(64, 15);
            lblCategoriaa.TabIndex = 6;
            lblCategoriaa.Text = "Categoria:";
            // 
            // lblEditoraa
            // 
            lblEditoraa.AutoSize = true;
            lblEditoraa.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEditoraa.Location = new Point(52, 280);
            lblEditoraa.Name = "lblEditoraa";
            lblEditoraa.Size = new Size(49, 15);
            lblEditoraa.TabIndex = 5;
            lblEditoraa.Text = "Editora:";
            // 
            // lblAutorr
            // 
            lblAutorr.AutoSize = true;
            lblAutorr.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAutorr.Location = new Point(52, 241);
            lblAutorr.Name = "lblAutorr";
            lblAutorr.Size = new Size(38, 15);
            lblAutorr.TabIndex = 4;
            lblAutorr.Text = "Autor:";
            // 
            // lblTituloo
            // 
            lblTituloo.AutoSize = true;
            lblTituloo.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTituloo.Location = new Point(52, 203);
            lblTituloo.Name = "lblTituloo";
            lblTituloo.Size = new Size(40, 15);
            lblTituloo.TabIndex = 3;
            lblTituloo.Text = "Título:";
            // 
            // txtBuscarLivro
            // 
            txtBuscarLivro.Location = new Point(52, 51);
            txtBuscarLivro.Name = "txtBuscarLivro";
            txtBuscarLivro.Size = new Size(174, 23);
            txtBuscarLivro.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(52, 27);
            label1.Name = "label1";
            label1.Size = new Size(174, 15);
            label1.TabIndex = 1;
            label1.Text = "Digite o livro que deseja buscar:";
            // 
            // btnBuscar
            // 
            btnBuscar.BackColor = Color.Indigo;
            btnBuscar.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBuscar.ForeColor = Color.White;
            btnBuscar.Location = new Point(99, 80);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(75, 23);
            btnBuscar.TabIndex = 0;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = false;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // Tela_BuscarLivro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(650, 450);
            Controls.Add(panel2);
            Controls.Add(panelSuperior);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Tela_BuscarLivro";
            Text = "Tela_BuscarLivro";
            panelSuperior.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            ((System.ComponentModel.ISupportInitialize)picCapa).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelSuperior;
        private Panel panel2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label6;
        private Label lblCategoriaa;
        private Label lblEditoraa;
        private Label lblAutorr;
        private Label lblTituloo;
        private TextBox txtBuscarLivro;
        private Label label1;
        private Button btnBuscar;
        private Label lblCapa;
        private PictureBox picCapa;
        private Label lblCategoria;
        private Label lblEditora;
        private Label lblAutor;
        private Label lblTitulo;
        private PictureBox picLogo;
    }
}